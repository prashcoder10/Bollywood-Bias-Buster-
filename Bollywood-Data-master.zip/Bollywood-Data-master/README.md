# Bollywood-Movie-Data

This repository contains four types of Bollywood Data: 
1. __scripts-data__
2. __trailers-data__ 
3. __wikipedia-data__ 
4. __images-data__ 

The corresponding README can be found in each folder for further reference. 
